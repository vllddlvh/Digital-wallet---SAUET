import argparse
import os
import signal
import subprocess
import sys
from datetime import datetime

ROOT    = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K6_DIR  = os.path.join(ROOT, 'k6')
MONITOR = os.path.join(ROOT, 'monitor')


def log(msg): print(f'[orchestrator] {msg}', flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--profile', required=True, choices=['smoke', 'load', 'stress'])
    ap.add_argument('--out', default=None)
    ap.add_argument('--base-url', default='http://localhost:8080')
    ap.add_argument('--no-sampler', action='store_true')
    args = ap.parse_args()

    ts = datetime.now().strftime('%Y-%m-%dT%H-%M-%S')
    out = args.out or os.path.join(ROOT, 'results', f'{args.profile}_{ts}')
    os.makedirs(out, exist_ok=True)
    log(f'out = {out}')

    # Sampler (optional, read-only monitoring).
    sampler = None
    sampler_csv = os.path.join(out, 'sampler.csv')
    if not args.no_sampler:
        try:
            sampler = subprocess.Popen(
                [sys.executable, os.path.join(MONITOR, 'sampler.py'),
                 '--interval', '2', '--out', sampler_csv],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            log(f'sampler pid={sampler.pid} → {sampler_csv}')
        except Exception as e:
            log(f'WARN: sampler không start được ({e}); tiếp tục không sampler')

    # k6 (blocking).
    k6_csv     = os.path.join(out, 'k6_raw.csv')
    k6_summary = os.path.join(out, 'k6_summary.json')
    env = os.environ.copy()
    env['PROFILE']  = args.profile
    env['BASE_URL'] = args.base_url

    k6_exit = -1
    try:
        proc = subprocess.run(
            ['k6', 'run',
             '--out', f'csv={k6_csv}',
             '--summary-export', k6_summary,
             '--quiet',
             os.path.join(K6_DIR, 'main.js')],
            cwd=K6_DIR, env=env, check=False,
        )
        k6_exit = proc.returncode
        log(f'k6 exit = {k6_exit} (0 = ok, 99 = threshold abort)')
    finally:
        if sampler is not None:
            try:
                sampler.send_signal(signal.SIGTERM)
                sampler.wait(timeout=10)
            except subprocess.TimeoutExpired:
                sampler.kill()

    if k6_exit == 0:
        return 0
    if k6_exit == 99:
        log('k6 aborted via stopCondition threshold (expected ở stress)')
        return 2
    log(f'WARN: k6 exit={k6_exit} (bất thường)')
    return 1


if __name__ == '__main__':
    sys.exit(main())